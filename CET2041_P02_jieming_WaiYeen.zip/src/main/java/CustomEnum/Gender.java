package CustomEnum;

/**
 * Cust enum for employee gender.
 */
public enum Gender {
    /**
     * M for male
     */
    M,

    /**
     * F for female.
     */
    F
}
